if [ ! -f /data/data/com.dshapp/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.dshapp/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.dshapp/files/home/.termux
	cp /data/data/com.dshapp/files/usr/share/examples/termux/termux.properties /data/data/com.dshapp/files/home/.termux/
fi
