##
## This script is sourced by /data/data/com.dshapp/files/usr/bin/login before executing shell.
##
